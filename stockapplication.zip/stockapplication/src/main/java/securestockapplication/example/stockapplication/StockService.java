package securestockapplication.example.stockapplication;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StockService {
    @Autowired
    private StockRepository stockRepository;

    public List<stock> findAll() {
        return stockRepository.findAll();
    }

    public void save(stock stock) {
        stockRepository.save(stock);
    }

    public stock findById(Long id) {
        return stockRepository.findById(id).orElse(null);
    }

    public void updateStockPrice(Long id, double newPrice) {
        stock stock = findById(id);
        if (stock != null) {
            stock.setPrice(newPrice); // Ensure this method exists in Stock
            stockRepository.save(stock);
        }
    }

    public List<stock> findStocksAbovePrice(double price) {
        return stockRepository.findByPriceGreaterThan(price);
    }
}
