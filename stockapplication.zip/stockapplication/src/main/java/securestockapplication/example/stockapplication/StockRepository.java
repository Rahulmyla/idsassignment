package securestockapplication.example.stockapplication;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StockRepository extends JpaRepository<stock, Long> {

  List<stock> findByPriceGreaterThan(double price);
}

