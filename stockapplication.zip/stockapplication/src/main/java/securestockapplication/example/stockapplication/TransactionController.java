package securestockapplication.example.stockapplication;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/transactions")
public class TransactionController {
    @Autowired
    private TransactionService transactionService;

    @GetMapping
    public String listTransactions(Model model) {
        model.addAttribute("transactions", transactionService.findAll());
        return "transactions";
    }

    @GetMapping("/create")
    public String showCreateTransactionForm(Model model) {
        model.addAttribute("transaction", new Transaction());
        return "createTransaction";
    }

    @PostMapping("/create")
    public String createTransaction(@ModelAttribute Transaction transaction) {
        transactionService.save(transaction);
        return "redirect:/transactions";
    }
}
