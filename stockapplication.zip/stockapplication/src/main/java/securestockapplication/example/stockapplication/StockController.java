package securestockapplication.example.stockapplication;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/stocks")
public class StockController {
    @Autowired
    private StockService stockService;

    @GetMapping
    public String listStocks(Model model) {
        model.addAttribute("stocks", stockService.findAll());
        return "stocks";
    }

    @GetMapping("/create")
    public String showCreateStockForm(Model model) {
        model.addAttribute("stock", new stock());
        return "createStock";
    }

    @PostMapping("/create")
    public String createStock(@ModelAttribute stock stock) {
        stockService.save(stock);
        return "redirect:/stocks";
    }
}

