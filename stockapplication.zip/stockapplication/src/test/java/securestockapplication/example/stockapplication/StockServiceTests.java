package securestockapplication.example.stockapplication;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest
@SpringJUnitConfig
public class StockServiceTests {

    @Mock
    private StockRepository stockRepository;

    @InjectMocks
    private StockService stockService;

    public StockServiceTests() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindAll() {
        when(stockRepository.findAll()).thenReturn(Collections.singletonList(new stock()));
        assertEquals(1, stockService.findAll().size());
    }

    @Test
    public void testSave() {
        stock stock = new stock();
        stockService.save(stock);
        verify(stockRepository, times(1)).save(stock);
    }

    @Test
    public void testUpdateStockPrice() {
        stock stock = new stock();
        stock.setPrice(100.0);
        when(stockRepository.findById(1L)).thenReturn(java.util.Optional.of(stock));
        
        stockService.updateStockPrice(1L, 200.0);
        assertEquals(200.0, stock.getPrice());
        verify(stockRepository, times(1)).save(stock);
    }
}
