package securestockapplication.example.stockapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
