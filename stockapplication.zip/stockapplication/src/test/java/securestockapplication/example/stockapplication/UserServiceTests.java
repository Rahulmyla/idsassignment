package securestockapplication.example.stockapplication;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@SpringBootTest
@SpringJUnitConfig
public class UserServiceTests {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    public UserServiceTests() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindByUsername() {
        AppUser user = new AppUser();
        user.setUsername("testUser");
        when(userRepository.findByUsername("testUser")).thenReturn(user);
        
        assertNotNull(userService.findByUsername("testUser"));
    }

    @Test
    public void testSave() {
        AppUser user = new AppUser();
        userService.save(user);
        verify(userRepository, times(1)).save(user);
    }
}
